# Groqee Web Assistant

Groqee is an ultra-fast, lightweight web assistant powered by Groq. This package allows users to run the Groqee Web Assistant locally.

## Features
- Upload context files and chat with Groqee.
- Voice input and output support.
- Mini-mode for compact UI.
- Run PowerShell commands directly from the interface.

## Installation

1. Clone the repository or download the package.
2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python app.py
   ```

## Environment Setup

Ensure you have Python 3.8 or higher installed. Create a virtual environment to isolate dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

## Quick Start

1. Double-click the `start_groqee.bat` file to set up and start the application.
   - This script will create a virtual environment, install dependencies, and launch the application.

2. Open your browser and navigate to `http://localhost:5000`.
3. Enter your GROQ API key and start interacting with Groqee.

## Packaging

To package the application for distribution:

1. Ensure all dependencies are listed in `requirements.txt`.
2. Build the package:
   ```bash
   python setup.py sdist
   ```
3. The package will be available in the `dist/` directory.

## License

&copy; 2025 John Daniel Dondlinger. All rights reserved.